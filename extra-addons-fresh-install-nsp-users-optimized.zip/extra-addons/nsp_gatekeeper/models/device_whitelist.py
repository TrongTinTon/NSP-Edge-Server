# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class DeviceWhitelist(models.Model):
    _name = "nsp.device.whitelist"
    _description = "NSP Device Whitelist"
    _rec_name = "serial_number"
    _order = "serial_number, id"

    serial_number = fields.Char(string="Serial", required=True, index=True, copy=False)
    model_number = fields.Char(string="Model")
    device_vendor = fields.Char(string="Vendor")
    device_type = fields.Selection([
        ("rfid_reader", "RFID Reader"),
        ("camera", "Camera"),
        ("other", "Other"),
    ], string="Device Type", required=True, default="rfid_reader", index=True)

    _sql_constraints = [
        ("serial_number_unique", "unique(serial_number)", "Serial must be unique in Device Whitelist."),
    ]

    @api.model
    def _normalize_serial(self, value):
        return str(value or "").strip().upper()

    @api.model_create_multi
    def create(self, vals_list):
        prepared = []
        for source in vals_list:
            vals = dict(source)
            vals["serial_number"] = self._normalize_serial(vals.get("serial_number"))
            vals["model_number"] = str(vals.get("model_number") or "").strip() or False
            vals["device_vendor"] = str(vals.get("device_vendor") or "").strip() or False
            prepared.append(vals)
        return super().create(prepared)

    def write(self, vals):
        values = dict(vals)
        if "serial_number" in values:
            values["serial_number"] = self._normalize_serial(values.get("serial_number"))
        if "model_number" in values:
            values["model_number"] = str(values.get("model_number") or "").strip() or False
        if "device_vendor" in values:
            values["device_vendor"] = str(values.get("device_vendor") or "").strip() or False
        return super().write(values)

    @api.constrains("serial_number")
    def _check_serial_number(self):
        for record in self:
            if not self._normalize_serial(record.serial_number):
                raise ValidationError(_("Serial is required."))
