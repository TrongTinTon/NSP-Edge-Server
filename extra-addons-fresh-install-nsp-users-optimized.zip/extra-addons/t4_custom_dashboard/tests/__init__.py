# -*- coding: utf-8 -*-
from . import test_search_panel_config
